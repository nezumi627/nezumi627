# Reporting a Vulnerability

If you discover a security vulnerability in follow-redirects please disclose it via [our huntr page](https://huntr.dev/repos/follow-redirects/follow-redirects). Bounties, CVE assignment, response times and past reports are all there.


Thank you for improving the security of follow-redirects.
